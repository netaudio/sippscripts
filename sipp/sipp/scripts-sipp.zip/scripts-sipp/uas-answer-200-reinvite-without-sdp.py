# $Id$
#
import inc_const as const

PJSUA = ["--null-audio --max-calls=1 $SIPP_URI"]

PJSUA_EXPECTS = [[0, const.STATE_CONFIRMED, "v"]]
