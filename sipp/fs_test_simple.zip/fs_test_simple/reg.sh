

sipp -i 192.168.101.22  -sf uas_t1.xml -inf uas_f.csv 192.168.101.8:5060 -l 10 -trace_msg -trace_screen -trace_err -p 12346 -m 10 -aa
pause
