
sipp -aa -i 192.168.101.104 -sf uac_t1.xml -inf uac_f.csv 192.168.101.8 -l 1 -m 1 -p 12346   -trace_msg -trace_screen -trace_err
pause

