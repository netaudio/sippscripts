

sipp -i 192.168.27.129  -sf reg.xml -inf uas.csv 192.168.27.149:5060 -l 1 -trace_screen -trace_err -p 12346 -m 1 -aa
pause
