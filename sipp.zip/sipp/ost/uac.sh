
sipp -aa -i 192.168.27.1 -sf uac.xml -inf uac.csv 192.168.27.149 -l 1 -m 1 -p 12346   -trace_msg -trace_screen -trace_err
pause

