#register batcher on master computer ,test for kamaillio
sipp -i 192.168.101.22  -sf reg4.xml -inf uas.csv 192.168.101.8:5060 -l 1 -trace_msg -trace_screen -trace_err -p 12346 -m 1 -aa

#sipp -i 192.168.101.22  -sf reg.xml -inf uas.csv 192.168.101.8:5060 -l 1 -trace_msg -trace_err -p 12346 -m 1 -aa
#register batcher on virual computer
#sipp -i 192.168.27.129  -sf reg.xml -inf uas.csv 192.168.27.149:5060 -l 1 -trace_screen -trace_err -p 12346 -m 1 -aa
#pause

#不进行鉴权的注册
 sipp -i 192.168.27.149  -sf reg4.xml -inf uas.csv 192.168.27.149:5060  -m 1
 