# $Id$
#
import inc_const as const

PJSUA = ["--null-audio --max-calls=1 --id sip:pjsua@localhost:$SIPP_PORT --mwi"]

PJSUA_EXPECTS = []
